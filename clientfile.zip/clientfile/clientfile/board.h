#ifndef BOARD_H
#define BOARD_H

void update_led_board(char board[8][9]); // 함수 선언

#endif
